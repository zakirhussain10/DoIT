//
//  DoITViewViewModel.swift
//  DoIT
//
//  Created by Jakir Hussain on 09/02/24.
//
import FirebaseFirestore
import Foundation

class DoITViewViewModel : ObservableObject{
    @Published var showingNewItemView = false
    
    private let userId: String
    
    init(userId: String) {
        self.userId = userId
    }
    
    
    /// delete to do list
    /// - Parameter id: id to delete
    func delete(id: String) {
        let db = Firestore.firestore()
        
        db.collection("users")
            .document(userId)
            .collection("todos")
            .document(id)
            .delete()
        
    }
    
}
