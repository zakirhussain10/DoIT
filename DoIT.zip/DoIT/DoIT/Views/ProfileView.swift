//
//  ProfileView.swift
//  DoIT
//
//  Created by Jakir Hussain on 09/02/24.
//

import SwiftUI

struct ProfileView: View {
    @StateObject var viewModel = ProfileViewViewModel()
    
    var body: some View {
        NavigationView{
            VStack{
                if let user = viewModel.user {
                    profile(user: user)
                }
                else {
                    Image(systemName: "timelapse")
                        .font(.system(size: 30))
                        .symbolEffect(.variableColor)
                       
                }
            }
            .navigationTitle("Profile")
        }
        .onAppear {
            viewModel.fetchUser()
        }
    }
    @ViewBuilder
    func profile(user: User) -> some View {
        Image(systemName: "person.fill")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .foregroundColor(Color.blue)
            .frame(width: 160.0, height: 160.0)
            .padding()
        
        VStack(alignment: .leading) {
            
                //Text("Name: ")
                Text(user.name)
                    .font(.system(size: 40))
                    .bold()
                    .autocapitalization(.allCharacters)
                    .padding()
            
            
                
                    Text("Email ")
                        .bold()
                    Text(user.email)
                        .font(.footnote)
                        .foregroundColor(Color(.secondaryLabel))
                        
                
                    Text("Joined ")
                        .bold()
                        
                    Text("\(Date(timeIntervalSince1970: user.joined).formatted(date: .abbreviated, time: .shortened))")
                        .font(.footnote)
                        .foregroundColor(Color(.secondaryLabel))
                
        }.padding()
        
        Button("Log Out"){
            viewModel.logout()
        }.tint(.red)
            .padding()
        Spacer()
    }
    
}

#Preview {
    ProfileView()
}
