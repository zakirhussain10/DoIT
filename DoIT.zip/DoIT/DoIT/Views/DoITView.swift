//
//  DoITView.swift
//  DoIT
//
//  Created by Jakir Hussain on 09/02/24.
//
import FirebaseFirestoreSwift
import SwiftUI

struct DoITView: View {
    @StateObject var viewModel: DoITViewViewModel
    @FirestoreQuery var items : [DoITItem]
    
   
    init(userId: String) {
      
        self._items = FirestoreQuery(
            collectionPath: "users/\(userId)/todos"
        )
        self._viewModel = StateObject(wrappedValue: DoITViewViewModel(userId: userId))
    }
    
    var body: some View {
        NavigationView{
            VStack{
                List(items) {item in
                    DoITItemView(item: item)
                        .swipeActions {
                            Button("Delete") {
                                viewModel.delete(id: item.id)
                            }
                            .tint(.red)

                        }
                }
                .listStyle(PlainListStyle())
            }
            .navigationTitle("To Do")
            .toolbar{
                Button {
                    //action
                    viewModel.showingNewItemView = true
                } label: {
                    Image(systemName: "plus")
                }
                
            }.sheet(isPresented: $viewModel.showingNewItemView){
                NewItemView(newItemPresented: $viewModel.showingNewItemView )
            }
        }
    }
}

#Preview {
    DoITView(userId: "uHsNdoyycuNpMUt70buCQDoghHz2")
}
