//
//  HeaderView.swift
//  DoIT
//
//  Created by Jakir Hussain on 09/02/24.
//

import SwiftUI

struct HeaderView: View {
    let title:String
    let subtitle: String
    let angle: Double
    let background: Color
    
    
    var body: some View {
        ZStack{
            RoundedRectangle(cornerRadius: 0)
                .foregroundColor(background)
                .rotationEffect(Angle(degrees: angle))
            VStack{
                Text(title)
                    .font(.system(size:100))
                    .foregroundColor(.white)
                    .bold()
                Text(subtitle)
                    .foregroundColor(.white)
                    .bold()
            }
        }.frame(width: UIScreen.main.bounds.width*3,height: 300)
            
    }
}

#Preview {
    HeaderView(title: "iDoIT", subtitle: "{I do small, but consistent}", angle: -5, background: .cyan)
}
