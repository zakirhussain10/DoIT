//
//  Button.swift
//  DoIT
//
//  Created by Jakir Hussain on 13/02/24.
//

import SwiftUI

struct DoITButton: View {
    let title: String
    let background: Color
    let action: () -> Void
    
    var body: some View {
        Button{
            action()
        }label: {
            ZStack{
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(background)
                Text(title).foregroundColor(.white).bold()
            }
        }
    }
}

#Preview {
    DoITButton(title: "Value", background: .cyan) {
        //action
    }
}
