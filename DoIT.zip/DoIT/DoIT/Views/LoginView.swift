//
//  LoginView.swift
//  DoIT
//
//  Created by Jakir Hussain on 09/02/24.
//

import SwiftUI

struct LoginView: View {
 @StateObject var viewModel = LoginViewViewModel()
    
    var body: some View {
        NavigationView{
            VStack{
                //Color(.black).ignoresSafeArea()
                //header
                
                    ZStack{
                    RoundedRectangle(cornerRadius: 0)
                        .foregroundColor(.cyan)
                        .rotationEffect(Angle(degrees: -5))
                        VStack{
                            Image("name")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                            Text("{I do small, but consistent}")
                                .foregroundColor(.white)
                                .bold()
                                .offset(y: -100)
                        }
                    
                }.offset(y: -70)
                
                
//                HeaderView(title: "iDoIT", subtitle: "{I do small, but consistent}", angle: -5, background: .cyan).offset(y: -70)
                //login form
               
                Form {
                    if !viewModel.errorMessage.isEmpty{
                        Text(viewModel.errorMessage)
                            .foregroundStyle(Color.orange)
                            .font(.system(size: 12))
                    }
                    
                    
                    TextField("Email Address", text: $viewModel.email)
                        .textFieldStyle(DefaultTextFieldStyle())
                        .autocorrectionDisabled()
                        .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                    SecureField("Password", text: $viewModel.password)
                        .textFieldStyle(DefaultTextFieldStyle())
                    
                    DoITButton(title: "Login ", background: .cyan){
                        viewModel.login()
                    }.padding()
                }
                .offset(y: -50)
                //create account
                VStack{
                    Text("Do not have an iDoIT ID?")
                    NavigationLink("Create yours now.", destination: RegisterView())
                }.padding(.bottom,30)
            }
        }
        
        
    }
}

#Preview {
    LoginView()
}
