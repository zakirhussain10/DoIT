//
//  NewItemView.swift
//  DoIT
//
//  Created by Jakir Hussain on 09/02/24.
//

import SwiftUI

struct NewItemView: View {
    @StateObject var viewModel = NewItemViewViewModel()
    @Binding var newItemPresented: Bool
    
    var body: some View {
        VStack{
            Text("New Item")
                .font(.system(size: 30))
                .bold()
                .padding(.top, 50)
            
            Form {
                // title
                TextField("Text", text: $viewModel.title)
                // due date
                DatePicker("Date", selection: $viewModel.dueDate)
                    .datePickerStyle(GraphicalDatePickerStyle())
                //button
                DoITButton(title: "Done", background: .pink){
                    if viewModel.canSave {
                        viewModel.save()
                        newItemPresented = false
                    } else  {
                        viewModel.showAlert = true
                    }
                }.padding()
            }
            .alert(isPresented: $viewModel.showAlert) {
                Alert(title: Text("Error"), message: Text("Please fill in All fields and select due date"))
            }
        }
    }
}

#Preview {
    NewItemView(newItemPresented: Binding(get: {return true} , set: {_ in }))
}
