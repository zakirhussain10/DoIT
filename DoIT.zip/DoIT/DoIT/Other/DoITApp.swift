//
//  DoITApp.swift
//  DoIT
//
//  Created by Jakir Hussain on 06/01/24.
//
import FirebaseCore
import SwiftUI

@main
struct DoITApp: App {
    init(){
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
